Licensing
=========

This software is governed by the CeCILL/CeCILL-C licenses under French law and
abiding by the rules of distribution of free software.

You can use, modify and/or redistribute the software under the terms
of the CeCILL/CeCILL-C licenses as circulated by CEA, CNRS and INRIA at
<http://www.cecill.info>.

These licenses are officially recognized by
[Open Source Initiative (OSI)](http://www.opensource.org/) as Open
Source licenses. Compatibility has also been improved (with the GNU
Affero GPL and the EUPL).

You can find the text of the complete CeCILL-C Licence (v1.0) by
following the links below:

- [English version](LICENSE-CeCILL-C-en.md)

- [French version](LICENSE-CeCILL-C-fr.md)

